def suma(a,b,c):
	print(a, "+", b, "+", c, "=", a + b + c)
#suma(5,10,15)

##Variante# 
#suma(c = 1, a = 2, b = 3)

##Variante# 
#suma(3, c = 1, b = 2)

##Variante# 
suma(C= 1, 7, a = 3)