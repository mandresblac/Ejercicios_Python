def estimado(nombre):
	print("Estimado,", nombre, "!")
nombre = input("Ingrese tu nombre:")
estimado(nombre)