def mensaje():
    	print("Ingrese un valor, para definir A, B y C. Consecutivamente:")

mensaje()
a = int(input())
mensaje()
b = int(input())
mensaje()
c = int(input())

print(a, "+", b, "+", c, "=", a + b + c)