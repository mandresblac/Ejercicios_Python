def multi(numero):
	for i in range (1,11):
		print(i*numero1)
numero1=int(input("Ingrese el número a multiplicar:"))
print("Resultado")
multi(numero1)